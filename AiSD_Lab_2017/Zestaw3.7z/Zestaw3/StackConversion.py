#Niestety nie zbytnio rozumiem Jakie w tym ma byc zastosowanie stosu, jeżeli sie dowiem to uzupelnie.. ;)
